﻿using Microsoft.AspNetCore.Mvc;

namespace MayaMobile.Controllers
{
    public class ServiciosController : Controller
    {
        public IActionResult IndexS()
        {
            return View();
        }
        public IActionResult Wifi()
        {
            return View();
        }
        public IActionResult Telefono()
        {
            return View();
        }
        public IActionResult Tv()
        {
            return View();
        }
        public IActionResult Money()
        {
            return View();
        }

        public IActionResult Planes()
        {
            return View();
        }
        public IActionResult Contacto()
        {
            return View();
        }
    }
}
