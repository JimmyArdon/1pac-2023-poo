﻿namespace MayaMobile.Models
{
    public class IrepositorioUsuario
    {
    }
}