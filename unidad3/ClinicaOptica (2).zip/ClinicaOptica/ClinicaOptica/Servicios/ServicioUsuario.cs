﻿namespace ClinicaOptica.Servicios
{
    public class ServicioUsuario : IServicioUsuarios
    {
        
    }
}
