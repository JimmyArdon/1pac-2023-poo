﻿namespace ClinicaOptica.Servicios
{
    public interface IServicioUsuarios
    {
        
    }
}