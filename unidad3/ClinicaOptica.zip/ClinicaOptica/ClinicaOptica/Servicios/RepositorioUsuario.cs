﻿using ClinicaOptica.Models;
using Dapper;
using Microsoft.Data.SqlClient;

namespace ClinicaOptica.Servicios
{
    public class RepositorioUsuario : IRepositorioUsuario
    {
        private readonly IConfiguration configuration;
        private readonly string connectionString;

        public RepositorioUsuario(IConfiguration configuration)
        {
            this.configuration = configuration;
            connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public async Task<IEnumerable<Usuario>> Obtener(int usuarioId)
        {
            using var connection = new SqlConnection(connectionString);
            return await connection.QueryAsync<Usuario>
                (@"SELECT Id, Nombre, Apellido, NombreUsuario
                FROM Usuario
                WHERE UsuarioId = @UsuarioId",
                new { usuarioId });
        }
        public async Task<Usuario> Crear(Usuario usuario)
        {
            using var connection = new SqlConnection(connectionString);
            var id = await connection.QuerySingleAsync<int>
                ($@"INSERT INTO Usuario
                (Nombre, Apellido, Email, NombreUsuario, Password ,UsuarioId)
                VALUES
                (@Nombre, @Apellido, @Email, @NombreUsuario, @Password @UsuarioId);
                SELECT SCOPE_IDENTITY();",
                usuario);
            usuario.Id = id;

            return usuario;
        }

        public async Task<Usuario> ObtenerPorId(int id, int usuarioId)
        {
            using var connection = new SqlConnection(connectionString);
            return await connection.QueryFirstOrDefaultAsync<Usuario>
                (@"SELECT Id,Nombre, Apellido, Email, NombreUsuario, PasswordHash ,UsuarioId
                FROM Usuario
                WHERE Id = @Id AND UsuarioId = @UsuarioId",
                new { id, usuarioId });

        }

        public async Task<bool> Existe(string Nombre, int usuarioId)
        {
            using var connection = new SqlConnection(connectionString);
            var existe = await connection.QueryFirstOrDefaultAsync<int>
                (@"SELECT 1
                FROM Usuario
                WHERE NombreUsuario = @NombreUsuario AND UsuarioId = @UsuarioId",
                new { Nombre, usuarioId });

            return existe == 1;

        }
    }
}
