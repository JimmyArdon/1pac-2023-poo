﻿namespace ClinicaOptica.Servicios
{
    public interface IServicioUsuario
    {
        int ObtenerUsuarioId();
    }
}
