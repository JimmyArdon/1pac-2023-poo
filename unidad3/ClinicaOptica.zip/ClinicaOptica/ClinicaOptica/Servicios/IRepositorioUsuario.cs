﻿using ClinicaOptica.Models;

namespace ClinicaOptica.Servicios
{
    public interface IRepositorioUsuario
    {
        Task<Usuario> Crear(Usuario usuario);
        Task<bool> Existe(string Nombre, int usuarioId);
        Task<IEnumerable<Usuario>> Obtener(int usuarioId);
        Task<Usuario> ObtenerPorId(int id, int usuarioId);
    }
}
