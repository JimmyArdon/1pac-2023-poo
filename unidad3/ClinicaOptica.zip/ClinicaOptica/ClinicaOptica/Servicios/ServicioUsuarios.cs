﻿namespace ClinicaOptica.Servicios
{
    public class ServicioUsuarios : IServicioUsuario
    {
        public int ObtenerUsuarioId()
        {
            return 1;
        }
    }
}
