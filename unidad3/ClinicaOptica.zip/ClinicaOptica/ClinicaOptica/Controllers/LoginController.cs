﻿namespace ClinicaOptica.Controllers
{
    public class LoginController
    {
    }
}
