﻿using ClinicaOptica.Models;
using ClinicaOptica.Servicios;
using Microsoft.AspNetCore.Mvc;
using Dapper;
using Microsoft.Data.SqlClient;

namespace ClinicaOptica.Controllers
{
    public class HomeController : Controller
    {
        private readonly IRepositorioUsuario repositorioUsuario;
        private readonly IServicioUsuario servicioUsuario;
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger
            ,IRepositorioUsuario repositorioUsuario, 
            IServicioUsuario servicioUsuario )
        {
            _logger = logger;
            this.repositorioUsuario = repositorioUsuario;
            this.servicioUsuario = servicioUsuario;
        }

        public async Task<IActionResult> Index()
        {
            var usuarioId = servicioUsuario.ObtenerUsuarioId();
            var tiposCuenta = await repositorioUsuario.Obtener(usuarioId);

            return View(tiposCuenta);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Crear()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Crear(Usuario usuario)
        {
            if (!ModelState.IsValid)
            {
                return View(usuario);
            }

            usuario.UsuarioId = servicioUsuario.ObtenerUsuarioId();
            
            var yaExisteTipoCuenta =
                await repositorioUsuario.Existe(usuario.NombreUsuario, usuario.UsuarioId);

            if (yaExisteTipoCuenta)
            {
                ModelState.AddModelError(nameof(usuario.NombreUsuario), $"El nombre {usuario.NombreUsuario} ya existe");
                return View(usuario);
            }

            var usuarioBD = await repositorioUsuario.Crear(usuario);

            return RedirectToAction("Index");
        }

       

        public IActionResult Recuperar()
        {
            return View();
        }

        public IActionResult PaginaPrincipal()
        {
            return View();
        }

        public async Task<IActionResult> VerificarExisteCuenta(string NombreUsuario)
        {
            var usuarioId = servicioUsuario.ObtenerUsuarioId();
            var yaExsisteTipoCuenta = await repositorioUsuario.Existe(NombreUsuario, usuarioId);

            if (yaExsisteTipoCuenta)
            {
                return Json($"El nombre {NombreUsuario} ya existe");
            }

            return Json(true);

        }
    }
}