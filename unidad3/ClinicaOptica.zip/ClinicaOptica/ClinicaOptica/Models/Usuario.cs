﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;


namespace ClinicaOptica.Models
{
    public class Usuario : IValidatableObject
    {
        public int Id { get; set; }
        [Display(Name = "Nombre")]
        [Required(ErrorMessage = "El {0} es requerido")]
        //[PrimeraLetraMayuscula]
        [Remote(action: "VerificarExisteCuenta", "Usuario")]
        public string Nombre { get; set; }
        [Display(Name = "Apellido")]
        [Required(ErrorMessage = "El {0} es requerido")]
        public string Apellido { get; set; }

        public int UsuarioId { get; set; }
        [Required(ErrorMessage = "El {0} es requerido")]
        [EmailAddress(ErrorMessage = "El {0} debe ser un correo electronico")]
        public string Email { get; set; }

        [Display(Name = "Nombre de Usuario")]
        [Required(ErrorMessage = "El {0} es requerido")]

        public string NombreUsuario {get; set;}

        [Display(Name = "Password")]
        [Required(ErrorMessage = "El {0} es requerido")]
        public string Password { get; set;}

        IEnumerable<ValidationResult> IValidatableObject.Validate(ValidationContext validationContext)
        {
            if (Nombre != null && Nombre.Length > 0)
            {
                var primeraLetra = Nombre.ToString()[0].ToString();
                if (primeraLetra != primeraLetra.ToUpper())
                {
                    yield return new ValidationResult("La primera letra debe ser mayúscula",
                        new[] { nameof(Nombre) });

                }
            }
        }

    }
}
