﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace basico.Tarea2_JAAO
{
    internal class Ejercicio06
    {
        public Ejercicio06()
        {
            Console.WriteLine("Un programa que muestre los números del 1 al 100 en la consola. (for)");

            Console.WriteLine("Mostrar los numeros del 1 al 100");

            for (int i = 0; i <= 100; i++)
            {
                
                Console.WriteLine(i);
            }
        }
    }
}
