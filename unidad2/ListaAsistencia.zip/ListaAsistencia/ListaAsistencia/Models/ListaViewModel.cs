﻿namespace ListaAsistencia.Models
{
    public class ListaViewModel
    {
        public IEnumerable<Persona> Personas { get; set; }
    }
}
