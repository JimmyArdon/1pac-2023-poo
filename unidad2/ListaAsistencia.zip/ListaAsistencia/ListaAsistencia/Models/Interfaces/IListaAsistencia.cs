﻿namespace ListaAsistencia.Models.Interfaces
{
    public interface IListaAsistencia
    {
        List<Persona> ObtenerLista();
    }
}
