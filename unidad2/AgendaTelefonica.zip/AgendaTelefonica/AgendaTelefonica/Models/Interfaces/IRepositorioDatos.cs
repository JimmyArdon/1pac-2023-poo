﻿namespace AgendaTelefonica.Models.Interfaces
{
    public interface IRepositorioDatos
    {
        List<Datos> ObtenerProyectos();
    }
}
