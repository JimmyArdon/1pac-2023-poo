﻿namespace AgendaTelefonica.Models
{
    public class ListaContactoViewModel
    {
        public List<Datos> _datos { get; set; }
    }
}
