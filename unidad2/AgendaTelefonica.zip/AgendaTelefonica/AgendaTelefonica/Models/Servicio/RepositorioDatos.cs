﻿using AgendaTelefonica.Models.Interfaces;

namespace AgendaTelefonica.Models.Servicio
{
    public class RepositorioDatos : IRepositorioDatos
    {
        public List<Datos> ObtenerProyectos()
        {
            return new List<Datos>();

        }
    }
}
